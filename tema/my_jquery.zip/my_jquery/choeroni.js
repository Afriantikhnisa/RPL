$('.angka_saja').on('keyup',function(){
	if ($(this).val()=='') {
		$(this).val('0');
	}
	if (isNaN($(this).val())) {
		$(this).val('0');
	}
	// $(this).val(parseInt($(this).val()));
	$(this).val(parseInt($(this).val()));
});

$('.form-control').on('keyup',function(e){
	if (e.keyCode==222) {
		var amankan 	= $(this).val();
		$(this).val(amankan.replace("'","`"));
	}
});

$('.tanggal').datepicker({
	format : "dd-mm-yyyy",
	autoclose : true
});